# Vajra Security — Android project (Live App Monitor)

Ye project WebView mein aapki HTML app chalata hai aur ek **Notification Listener** jodta hai,
jo doosre apps ke notifications (SMS, WhatsApp, email...) ko phone par hi scan karke scam par alert deta hai.

IMPORTANT: ye project is sandbox mein compile NAHI ho paya (Android SDK nahi tha). Sirf scam-engine (FraudEngine)
Java mein test hua hai aur HTML ke sath match kiya gaya. Pehli build mein chhoti error aa sakti hai — build log bhej dena.

## APK banane ke 2 tarike
**A) GitHub (laptop nahi chahiye)**
1. github.com par naya repo banao, is folder ki saari files upload karo (`.github` folder bhi).
2. Repo ke *Actions* tab mein "Build APK" chalega. Khatam hone par *Artifacts → VajraSecurity-debug-apk* download karo.
3. APK phone mein install karo (Unknown sources allow).

**B) Android Studio**: folder open karo → Build → Build APK(s).

## Use kaise karein
1. App kholo → Antivirus tab → **Live App Monitor → Turn on** → disclosure "Agree" karo.
2. Android Settings mein *Vajra Security* ko Notification Access do.
3. Test: kisi dusre app se ye text notification mein bhejo (e.g. khud ko WhatsApp):
   `Your SBI account will be blocked today. Update KYC now http://sbi-kyc-update.xyz/login`
   → Vajra "Scam warning" notification dega.
Android 13+: Vajra ko Notifications permission bhi allow karo, warna alert nahi dikhega.
Kuch phones (Xiaomi/Oppo/Vivo...) battery optimisation se listener band kar dete hain — Vajra ko "No restrictions" do.

## Index.html update karna
`app/src/main/assets/index.html` replace karo. Agar rules badle: 
`python3 tools/gen_rules.py index.html app/src/main/java/com/htmltoapk/vajrasecurity/Rules.java`

## Play Store
- Release ke liye signed **AAB** chahiye (keystore), debug APK sirf sideload ke liye.
- Notification Listener sensitive hai: Privacy Policy URL, Data Safety form aur app ke andar prominent disclosure (HTML mein hai) zaroori hain.
  Review reject ho sakta hai; policy tayyar rakho. Message text upload nahi hota.
- Firebase (cloud sync) abhi HTML wale JS SDK se chalta hai; google-services.json is project mein nahi chahiye.
