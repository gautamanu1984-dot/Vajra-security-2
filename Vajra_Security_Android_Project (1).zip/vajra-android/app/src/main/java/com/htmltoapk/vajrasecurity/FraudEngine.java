package com.htmltoapk.vajrasecurity;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Rule-based scam detector. A line-by-line port of the analyze() / urlRisk() code in index.html,
 * so the phone service and the app screen give the same answer. The rule data lives in Rules.java
 * (generated from index.html). Pure Java: no Android classes, so it can be unit-tested anywhere.
 */
final class FraudEngine {
    private FraudEngine() {}

    static final class Result {
        final int score;
        final String level; // "danger", "warn" or "safe"
        final List<String> reasons;
        final List<String> links;

        Result(int score, String level, List<String> reasons, List<String> links) {
            this.score = score;
            this.level = level;
            this.reasons = reasons;
            this.links = links;
        }
    }

    static final class UrlResult {
        int score;
        List<String> reasons = new ArrayList<>();
        String host = "";
        boolean trusted;
    }

    private static final class Rule {
        Pattern re;
        Pattern and;
        Pattern not;
        int w;
        String why;
    }

    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final List<Rule> RULE_LIST = new ArrayList<>();
    private static final Pattern LINK = Pattern.compile(
            "(https?://[^\\s]+|www\\.[^\\s]+|\\b[a-z0-9-]+(\\.[a-z0-9-]+)*\\.(?:xyz|top|click|icu|live|site|online|shop|buzz|vip|win|loan|zip|co\\.in|in|com|net|org)(/[^\\s]*)?)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern URL_WORDS = Pattern.compile(
            "login|verify|secure|update|kyc|reward|prize|claim|refund|otp|support|wallet|bonus|free|gift|lucky|offer|suspend|unlock");
    private static final Pattern LONG_NUMBER = Pattern.compile("\\b\\d{10,}\\b");
    private static final Pattern CALL_WORDS = Pattern.compile("call|कॉल|whatsapp|contact", FLAGS);
    private static final Pattern IP_HOST = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}$");

    static {
        for (String[] r : Rules.RULES) {
            Rule rule = new Rule();
            rule.re = Pattern.compile(r[0], FLAGS);
            rule.and = r[1] == null ? null : Pattern.compile(r[1], FLAGS);
            rule.not = r[2] == null ? null : Pattern.compile(r[2], FLAGS);
            rule.w = Integer.parseInt(r[3]);
            rule.why = r[4];
            RULE_LIST.add(rule);
        }
    }

    private static boolean contains(String[] list, String value) {
        for (String s : list) {
            if (s.equals(value)) return true;
        }
        return false;
    }

    private static boolean hostOk(String h) {
        for (String d : Rules.OFFICIAL) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    static List<String> findLinks(String text) {
        List<String> out = new ArrayList<>();
        Matcher m = LINK.matcher(text);
        while (m.find() && out.size() < 5) {
            out.add(m.group());
        }
        return out;
    }

    static UrlResult urlRisk(String rawIn) {
        UrlResult res = new UrlResult();
        String raw = rawIn.trim().replaceAll("[.,;)\\]]+$", "");
        String full = raw.matches("(?is)^[a-z][a-z0-9+.-]*://.*") ? raw : "http://" + raw;

        int start = full.indexOf("://") + 3;
        int end = full.length();
        char[] stops = {'/', '?', '#'};
        for (char c : stops) {
            int k = full.indexOf(c, start);
            if (k >= 0 && k < end) end = k;
        }
        String auth = full.substring(start, end);
        String path = "/";
        if (end < full.length() && full.charAt(end) == '/') {
            path = full.substring(end).split("[?#]")[0];
        }
        int at = auth.lastIndexOf('@');
        if (at >= 0) auth = auth.substring(at + 1);
        int colon = auth.lastIndexOf(':');
        if (colon >= 0) auth = auth.substring(0, colon);
        String h = auth.toLowerCase(Locale.ROOT);

        if (h.isEmpty() || h.contains(" ")) {
            res.score = 40;
            res.reasons.add("URL format is invalid");
            res.host = raw;
            return res;
        }
        res.host = h;
        if (hostOk(h)) {
            res.score = 0;
            res.trusted = true;
            return res;
        }

        int s = 0;
        List<String> r = res.reasons;
        if (raw.toLowerCase(Locale.ROOT).startsWith("http://")) {
            s += 12;
            r.add("Not HTTPS (insecure connection)");
        }
        if (IP_HOST.matcher(h).matches()) {
            s += 35;
            r.add("Raw IP address instead of a domain");
        }
        if (raw.contains("@")) {
            s += 30;
            r.add("Contains \"@\" — a trick to hide the real site");
        }
        if (h.contains("xn--")) {
            s += 30;
            r.add("Punycode domain (look-alike characters)");
        }
        if (contains(Rules.SHORT, h)) {
            s += 25;
            r.add("Short link — real destination is hidden");
        }
        String tld = h.substring(h.lastIndexOf('.') + 1);
        if (contains(Rules.RISKTLD, tld)) {
            s += 20;
            r.add("Risky domain extension (." + tld + ")");
        }
        if (h.split("\\.").length > 4) {
            s += 12;
            r.add("Too many subdomains");
        }
        int hyphens = 0;
        for (int i = 0; i < h.length(); i++) {
            if (h.charAt(i) == '-') hyphens++;
        }
        if (hyphens >= 2) {
            s += 10;
            r.add("Many hyphens in domain");
        }
        Set<String> words = new LinkedHashSet<>();
        Matcher km = URL_WORDS.matcher(h + path);
        while (km.find()) words.add(km.group());
        if (!words.isEmpty()) {
            s += Math.min(30, words.size() * 12);
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (String w : words) {
                if (n == 3) break;
                if (n > 0) sb.append(", ");
                sb.append(w);
                n++;
            }
            r.add("Suspicious words: " + sb);
        }
        for (String b : Rules.BRANDS) {
            if (h.contains(b)) {
                s += 30;
                r.add("\"" + b + "\" brand look-alike — not the real domain");
                break;
            }
        }
        if (raw.length() > 90) {
            s += 8;
            r.add("Very long URL");
        }
        res.score = Math.min(100, s);
        return res;
    }

    static Result analyze(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        int score = 0;
        List<String> reasons = new ArrayList<>();
        for (Rule rule : RULE_LIST) {
            if (rule.re.matcher(t).find()
                    && (rule.and == null || rule.and.matcher(t).find())
                    && (rule.not == null || !rule.not.matcher(t).find())) {
                score += rule.w;
                reasons.add(rule.why);
            }
        }
        List<String> links = findLinks(text);
        for (String l : links) {
            UrlResult u = urlRisk(l);
            if (u.score >= 25) {
                score += Math.min(30, u.score);
                reasons.add("Suspicious link: " + u.host + " (" + u.reasons.get(0) + ")");
            } else if (!u.trusted) {
                score += 6;
            }
        }
        if (LONG_NUMBER.matcher(text).find() && CALL_WORDS.matcher(text).find() && score > 15) {
            score += 6;
            reasons.add("Asks you to call / contact an unknown number");
        }
        score = Math.min(100, score);
        String level = score >= 55 ? "danger" : score >= 25 ? "warn" : "safe";
        return new Result(score, level, reasons, links);
    }

    /**
     * Policy for the live notification monitor. Ordinary chats trip single weak rules, so a "warn"
     * only raises an alert when the message also carries a link. "danger" always does.
     */
    static boolean shouldAlert(Result r) {
        if ("danger".equals(r.level)) return true;
        return "warn".equals(r.level) && !r.links.isEmpty();
    }
}
