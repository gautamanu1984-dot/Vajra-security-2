package com.htmltoapk.vajrasecurity;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Keeps the last alerts on the device only (SharedPreferences). Nothing is uploaded. */
final class AlertStore {
    private static final String PREFS = "vajra_alerts";
    private static final String KEY = "list";
    private static final int MAX = 50;

    private AlertStore() {}

    static synchronized void add(Context c, String pkg, String app, FraudEngine.Result r, String preview) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(KEY, "[]"));
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("pkg", pkg);
            o.put("app", app);
            o.put("score", r.score);
            o.put("level", r.level);
            JSONArray why = new JSONArray();
            for (int i = 0; i < r.reasons.size() && i < 4; i++) why.put(r.reasons.get(i));
            o.put("reasons", why);
            o.put("preview", preview);
            JSONArray out = new JSONArray();
            out.put(o);
            for (int i = 0; i < old.length() && out.length() < MAX; i++) out.put(old.get(i));
            sp.edit().putString(KEY, out.toString()).apply();
        } catch (JSONException ignored) {
        }
    }

    static synchronized String json(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
    }

    static synchronized void clear(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
